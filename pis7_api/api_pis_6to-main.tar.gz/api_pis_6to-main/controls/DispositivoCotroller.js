'use strict';
const axios = require('axios');
var models = require('../models');
//const cron = require('cron');
const path = require('path');
const fs = require('fs/promises');
const { Console } = require('console');
class DispositivoController {

   
    async traerIndiceUV(req, res) {
        console.log('**-*****vvv**-------');
        try {
            console.log('**-*****vvv**-------');
            const job = new cron.CronJob('*/1 * * * *', async function () {
                // Realizar la solicitud GET al servidor externo
                const response = await axios.get('http://10.20.202.161/console?comando=');
                console.log();
                console.log('**-*****vvv**-------');
                console.log('http://10.20.201.36/console?comando=');
                //    console.log(response);
                // Si el servidor responde con éxito
                //       console.log(response);
                if (response.data.code === 200 || true) {
                    //   if (true) {
                    let transaction = await models.sequelize.transaction();
                    if (response !== null || true) {
                        try {
                            const data = {
                                "indice_uv": 10.4,
                                "id_dispositivo": 1
                            }
                            //    console.log(data + '-----------------------------------');
                            await models.medicion.create(data, transaction);
                            await transaction.commit(); error.message
                            console.log("UV traido");
                            res.json({ msg: 'OK!', code: 200, info: "asda da", time: 3360 });
                        } catch (error) {
                            if (transaction) await transaction.rollback();
                            if (error.errors && error.errors[0].message) {
                                console.log("UV Error");
                            } else {
                                console.log("UV Error");
                            }
                        }
                    } else {
                        console.log("Peticion error");
                    }
                    // res.json({ msg: 'OK!', code: 200, info: "asda da", time: 3360 });

                } else {
                    // Si la respuesta del servidor no es 200
                    res.json({ msg: "Error al realizar la solicitud al servidor externo 1", code: response.status, info: [] });
                }


                console.log('Tarea programada ejecutada');
            });

            // Iniciar la tarea cron
            job.start();
        } catch (error) {
            // Resto del código para manejar errores...
            console.log(error);
            res.json({ msg: "Error al realizar la solicitud al servidor externo", code: 400, error: error, info: [] });
        }
    }

   
}

module.exports = DispositivoController;